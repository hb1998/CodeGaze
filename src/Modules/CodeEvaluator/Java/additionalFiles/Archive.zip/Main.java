import com.fasterxml.jackson.databind.ObjectMapper;

public class Main {
    public static void main(String[] args) {
        String jsonString = "[{  \"A\":11 ,  \"B\": \"test\",  \"C\": 1000}]";
            System.out.println(getObject(jsonString));
        
    }
    
    public static Object getObject(String jsonString){
       try {
            ObjectMapper objectMapper = new ObjectMapper();
            Object javaObject = objectMapper.readValue(jsonString, Object.class);

            // Now, javaObject contains the appropriate Java representation of the JSON data
            return javaObject;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
