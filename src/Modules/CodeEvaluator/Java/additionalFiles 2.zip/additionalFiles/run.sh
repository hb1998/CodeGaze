#!/bin/bash
# /usr/local/openjdk13/bin/java -cp "lib/*:." Main
echo test